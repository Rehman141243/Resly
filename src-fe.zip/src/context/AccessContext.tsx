import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";

import {
  preloadInterstitial,
  preloadRewarded,
  showInterstitial,
  showRewarded,
} from "../services/rewardedAds";
import type { TemplateInfo } from "../types/resume";
import { AdAccess, adsService } from "../services/adsService";
import { ADS_TEST_MODE } from "../config/env";

export type UnlockOutcome =
  | { status: "unlocked" | "progress"; watched: number; required: number }
  | { status: "cancelled" | "no_ad" | "pending" };

type Ctx = {
  access: AdAccess | null;

  showAds: boolean;
  isPremium: boolean;
  refresh: () => Promise<AdAccess | null>;

  canUse: (tpl: Pick<TemplateInfo, "id" | "premium">) => boolean;

  watched: (templateId: string) => number;

  prepareUnlock: (templateId: string) => void;

  unlockWithAd: (templateId: string) => Promise<UnlockOutcome>;

  withAd: <T>(action: () => Promise<T>) => Promise<T>;
};

const AccessCtx = createContext<Ctx | null>(null);
const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

export function AccessProvider({
  userId,
  children,
}: {
  userId: string | null;
  children: React.ReactNode;
}) {
  const [access, setAccess] = useState<AdAccess | null>(null);
  const accessRef = useRef<AdAccess | null>(null);
  accessRef.current = access;

  const refresh = useCallback(async () => {
    if (!userId) {
      setAccess(null);
      return null;
    }
    try {
      const a = await adsService.access();
      setAccess(a);
      return a;
    } catch {
      return accessRef.current;
    }
  }, [userId]);

  useEffect(() => {
    setAccess(null);
    if (userId) void refresh();
  }, [userId, refresh]);

  const showAds = !!access && access.showAds;
  const showAdsRef = useRef(showAds);
  showAdsRef.current = showAds;

  useEffect(() => {
    if (showAds) preloadInterstitial();
  }, [showAds]);

  const canUse = useCallback<Ctx["canUse"]>(
    (tpl) => !tpl.premium || !!access?.premium || !!access?.unlocked.includes(tpl.id),
    [access],
  );

  const watched = useCallback((id: string) => access?.progress[id] ?? 0, [access]);

  const prepareUnlock = useCallback(
    (templateId: string) => {
      if (userId) preloadRewarded(userId, templateId);
    },
    [userId],
  );

  const unlockWithAd = useCallback<Ctx["unlockWithAd"]>(
    async (templateId) => {
      if (!userId) return { status: "no_ad" };
      const was = accessRef.current?.progress[templateId] ?? 0;

      let earned = false;
      try {
        earned = await showRewarded(userId, templateId);
      } catch {
        return { status: "no_ad" };
      }
      if (!earned) return { status: "cancelled" };

      const summarize = (a: AdAccess | null): UnlockOutcome | null => {
        if (!a) return null;
        const w = a.progress[templateId] ?? 0;
        if (a.unlocked.includes(templateId))
          return { status: "unlocked", watched: a.adsRequired, required: a.adsRequired };
        if (w > was) return { status: "progress", watched: w, required: a.adsRequired };
        return null;
      };

      if (ADS_TEST_MODE) {
        try {
          await adsService.testReport(templateId);
        } catch {}
        const out = summarize(await refresh());
        if (out) return out;
      }

      for (let i = 0; i < 6; i++) {
        await sleep(1500);
        const out = summarize(await refresh());
        if (out) return out;
      }
      return { status: "pending" };
    },
    [userId, refresh],
  );

  const withAd = useCallback(async <T,>(action: () => Promise<T>): Promise<T> => {
    if (!showAdsRef.current) return action();

    const [, res] = await Promise.allSettled([showInterstitial(), action()]);

    if (res.status === "rejected") throw res.reason;
    return res.value;
  }, []);

  const value = useMemo<Ctx>(
    () => ({
      access,
      showAds,
      isPremium: !!access?.premium,
      refresh,
      canUse,
      watched,
      prepareUnlock,
      unlockWithAd,
      withAd,
    }),
    [access, showAds, refresh, canUse, watched, prepareUnlock, unlockWithAd, withAd],
  );

  return <AccessCtx.Provider value={value}>{children}</AccessCtx.Provider>;
}

export function useAccess(): Ctx {
  const v = useContext(AccessCtx);
  if (!v) throw new Error("useAccess must be used inside <AccessProvider>");
  return v;
}
