import { useMemo, useState } from "react";
import { ActivityIndicator, Linking, Pressable, Text, View } from "react-native";
import type { PurchasesPackage } from "react-native-purchases";
import Button from "../Button";
import Icon, { IconName } from "../common/Icon";
import { useTheme } from "../../context/ThemeContext";
import { PRIVACY_URL, TERMS_URL } from "../../config/env";

export const PERKS: { icon: IconName; text: string }[] = [
  { icon: "layout", text: "All premium templates" },
  { icon: "cpu", text: "More AI-written resumes every day" },
  { icon: "file-text", text: "Save more resumes" },
  { icon: "download", text: "High-quality PDF download" },
];

export function Perks() {
  const { colors } = useTheme();
  return (
    <View>
      {PERKS.map((p, i) => (
        <View
          key={p.text}
          className={`flex-row items-center ${i === PERKS.length - 1 ? "" : "mb-3"}`}
        >
          <View className="h-9 w-9 items-center justify-center rounded-full bg-brand/10 dark:bg-brand-dark/20">
            <Icon name={p.icon} size={17} color={colors.brand} />
          </View>
          <Text className="ml-3 flex-1 text-[16px] text-ink dark:text-ink-dark">{p.text}</Text>
        </View>
      ))}
    </View>
  );
}

const LABEL: Record<string, string> = {
  WEEKLY: "Weekly",
  MONTHLY: "Monthly",
  TWO_MONTH: "2 months",
  THREE_MONTH: "3 months",
  SIX_MONTH: "6 months",
  ANNUAL: "Yearly",
  LIFETIME: "Lifetime",
};
const label = (p: PurchasesPackage) => LABEL[String(p.packageType)] ?? p.product.title;

type PlanListProps = {
  packages: PurchasesPackage[];
  loading: boolean;
  busy: boolean;
  error: string | null;
  onBuy: (pkg: PurchasesPackage) => void;
  onRetry: () => void;
};

export function PlanList({ packages, loading, busy, error, onBuy, onRetry }: PlanListProps) {
  const { colors } = useTheme();
  const [picked, setPicked] = useState<string | null>(null);

  const monthly = packages.find((p) => String(p.packageType) === "MONTHLY");
  const annual = packages.find((p) => String(p.packageType) === "ANNUAL");
  const save = useMemo(() => {
    if (!monthly || !annual || !monthly.product.price) return 0;
    return Math.round((1 - annual.product.price / (monthly.product.price * 12)) * 100);
  }, [monthly, annual]);

  const selectedId = picked ?? (annual ?? packages[0])?.identifier;
  const selected = packages.find((p) => p.identifier === selectedId);

  if (loading) {
    return (
      <View className="items-center py-8">
        <ActivityIndicator color={colors.brand} />
      </View>
    );
  }

  if (packages.length === 0) {
    return (
      <View className="items-center py-6">
        <Text className="text-center text-[14px] leading-5 text-muted dark:text-muted-dark">
          {error ?? "Plans are not available right now."}
        </Text>
        <Pressable onPress={onRetry} hitSlop={10} className="mt-3">
          <Text className="text-[15px] font-semibold text-brand dark:text-brand-dark">
            Try again
          </Text>
        </Pressable>
      </View>
    );
  }

  return (
    <View>
      {packages.map((p) => {
        const on = p.identifier === selectedId;
        return (
          <Pressable
            key={p.identifier}
            onPress={() => setPicked(p.identifier)}
            className={`mb-2.5 flex-row items-center rounded-2xl border px-4 py-3.5 ${
              on
                ? "border-brand bg-brand/10 dark:border-brand-dark dark:bg-brand-dark/15"
                : "border-[#C6C6C8] dark:border-[#38383A]"
            }`}
          >
            <View
              className={`h-5 w-5 items-center justify-center rounded-full border ${
                on
                  ? "border-brand bg-brand dark:border-brand-dark dark:bg-brand-dark"
                  : "border-[#C6C6C8] dark:border-[#38383A]"
              }`}
            >
              {on ? <Icon name="check" size={12} color="#FFFFFF" /> : null}
            </View>
            <View className="ml-3 flex-1">
              <Text className="text-[16px] font-semibold text-ink dark:text-ink-dark">
                {label(p)}
              </Text>
              {p === annual && save > 0 ? (
                <Text className="text-[12px] font-semibold text-brand dark:text-brand-dark">
                  Save {save}%
                </Text>
              ) : null}
            </View>
            <Text className="text-[16px] font-semibold text-ink dark:text-ink-dark">
              {p.product.priceString}
            </Text>
          </Pressable>
        );
      })}

      {error ? (
        <Text className="mb-2 mt-1 text-center text-[14px] text-red-500 dark:text-[#FF453A]">
          {error}
        </Text>
      ) : null}

      <View className="mt-2">
        <Button
          title={selected ? `Continue  ·  ${selected.product.priceString}` : "Continue"}
          onPress={() => selected && onBuy(selected)}
          loading={busy}
        />
      </View>
    </View>
  );
}

export function LegalNote({ onRestore, busy }: { onRestore: () => void; busy: boolean }) {
  return (
    <View>
      <Pressable onPress={onRestore} disabled={busy} hitSlop={10} className="mt-4 items-center">
        <Text className="text-[15px] font-semibold text-brand dark:text-brand-dark">
          Restore purchases
        </Text>
      </Pressable>

      <Text className="mt-4 text-center text-[12px] leading-4 text-muted dark:text-muted-dark">
        Payment is charged to your App Store or Google Play account. The subscription renews
        automatically unless you cancel at least 24 hours before the period ends. Manage or cancel
        any time in your store account settings.
      </Text>

      {TERMS_URL || PRIVACY_URL ? (
        <View className="mt-2 flex-row justify-center">
          {TERMS_URL ? (
            <Pressable onPress={() => Linking.openURL(TERMS_URL)} hitSlop={8}>
              <Text className="text-[12px] text-muted underline dark:text-muted-dark">
                Terms of Use
              </Text>
            </Pressable>
          ) : null}
          {TERMS_URL && PRIVACY_URL ? (
            <Text className="mx-2 text-[12px] text-muted dark:text-muted-dark">·</Text>
          ) : null}
          {PRIVACY_URL ? (
            <Pressable onPress={() => Linking.openURL(PRIVACY_URL)} hitSlop={8}>
              <Text className="text-[12px] text-muted underline dark:text-muted-dark">
                Privacy Policy
              </Text>
            </Pressable>
          ) : null}
        </View>
      ) : null}
    </View>
  );
}
