import { View } from "react-native";
import type { PurchasesPackage } from "react-native-purchases";
import BottomSheet from "../common/BottomSheet";
import { LegalNote, PlanList, Perks } from "./BillingParts";

type Props = {
  visible: boolean;
  reason?: string | null;
  packages: PurchasesPackage[];
  loading: boolean;
  busy: boolean;
  error: string | null;
  onBuy: (pkg: PurchasesPackage) => void;
  onRestore: () => void;
  onRetry: () => void;
  onClose: () => void;
};

export default function PaywallSheet({
  visible,
  reason,
  packages,
  loading,
  busy,
  error,
  onBuy,
  onRestore,
  onRetry,
  onClose,
}: Props) {
  return (
    <BottomSheet
      visible={visible}
      onClose={onClose}
      title="Go Premium"
      subtitle={reason ?? "Unlock every template and get more from AI."}
    >
      <View className="mb-4">
        <Perks />
      </View>
      <PlanList
        packages={packages}
        loading={loading}
        busy={busy}
        error={error}
        onBuy={onBuy}
        onRetry={onRetry}
      />
      <LegalNote onRestore={onRestore} busy={busy} />
    </BottomSheet>
  );
}
