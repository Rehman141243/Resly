import { Text, View } from "react-native";
import Ionicons from "react-native-vector-icons/Ionicons";
import { TemplateInfo } from "../../types/resume";

export default function TemplateBadges({
  item,
  locked,
  showPro = true,
}: {
  item: TemplateInfo;
  locked: boolean;

  showPro?: boolean;
}) {
  return (
    <>
      {showPro && item.premium ? (
        <View
          style={{
            position: "absolute",
            top: 8,
            left: 8,
            flexDirection: "row",
            alignItems: "center",
            backgroundColor: "#F5A623",
            borderRadius: 8,
            paddingHorizontal: 7,
            paddingVertical: 2,
          }}
        >
          <Ionicons name={locked ? "lock-closed" : "star"} size={10} color="#FFFFFF" />
          <Text
            style={{
              fontSize: 10,
              fontWeight: "800",
              color: "#fff",
              letterSpacing: 0.4,
              marginLeft: 3,
            }}
          >
            PRO
          </Text>
        </View>
      ) : null}
      {item.hasPhoto ? (
        <View
          style={{
            position: "absolute",
            top: 8,
            right: 8,
            backgroundColor: "rgba(0,0,0,0.65)",
            borderRadius: 8,
            paddingHorizontal: 7,
            paddingVertical: 2,
          }}
        >
          <Text style={{ fontSize: 10, fontWeight: "700", color: "#fff", letterSpacing: 0.4 }}>
            PHOTO
          </Text>
        </View>
      ) : null}
    </>
  );
}
