import { useEffect, useState, useCallback } from "react";
import { Button, View } from "react-native";
import { InterstitialAd, AdEventType, TestIds } from "react-native-google-mobile-ads";

const unitId = __DEV__ ? TestIds.INTERSTITIAL : "YOUR_INTERSTITIAL_AD_UNIT_ID";

const interstitial = InterstitialAd.createForAdRequest(unitId);

export default function AdBanner() {
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const loadedListener = interstitial.addAdEventListener(AdEventType.LOADED, () =>
      setLoaded(true),
    );

    const closedListener = interstitial.addAdEventListener(AdEventType.CLOSED, () => {
      setLoaded(false);
      interstitial.load();
    });

    const errorListener = interstitial.addAdEventListener(AdEventType.ERROR, (error) => {
      setLoaded(false);
    });

    interstitial.load();

    return () => {
      loadedListener();
      closedListener();
      errorListener();
    };
  }, []);

  const showAd = useCallback(() => {
    if (loaded) {
      interstitial.show();
    } else {
    }
  }, [loaded]);

  return (
    <View>
      <Button title="Show Interstitial Ad" onPress={showAd} disabled={!loaded} />
    </View>
  );
}
