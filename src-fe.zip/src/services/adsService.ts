import api from "./apiClient";

export type AdAccess = {
  premium: boolean;
  showAds: boolean;
  adsRequired: number;
  unlocked: string[];
  progress: Record<string, number>;
};

export const adsService = {
  async access(): Promise<AdAccess> {
    const { data } = await api.get("/ads/access");
    return {
      premium: !!data.premium,
      showAds: !!data.showAds,
      adsRequired: Number(data.adsRequired) || 3,
      unlocked: Array.isArray(data.unlocked) ? data.unlocked : [],
      progress: data.progress ?? {},
    };
  },

  async testReport(templateId: string) {
    const { data } = await api.post("/ads/test-report", { templateId });
    return data as { success: boolean; watched: number; unlocked: boolean };
  },
};

export const isLockedError = (e: unknown): boolean => {
  const r = (e as any)?.response;
  const code = r?.data?.code;
  if (typeof code === "string") return code === "PREMIUM_REQUIRED" || code === "TEMPLATE_LOCKED";
  return r?.status === 402;
};
